# 🎙 The Voice of Rockstar'z — Full Deployment Guide

## Architecture
```
frontend/   → Static HTML/CSS/JS  → Deploy to Netlify (FREE)
backend/    → Node.js + SQLite     → Deploy to Railway (FREE tier)
```

---

## STEP 1 — Deploy the Backend (Railway)

1. Go to **https://railway.app** → Sign up / Login with GitHub
2. Click **"New Project"** → **"Deploy from GitHub repo"**
   - Or use **"Empty project"** → **"Deploy from local"**
3. Drag & drop the `backend/` folder **OR** push it to a GitHub repo and connect
4. Railway auto-detects Node.js and runs `npm start`
5. Go to your project → **Settings** → **Networking** → click **"Generate Domain"**
6. Copy the URL — it looks like: `https://rockstarz-backend-production.up.railway.app`

**That's your API URL.** The database (`rockstarz.db`) is created automatically on first run.

---

## STEP 2 — Set the API URL in the Frontend

Open `frontend/index.html` and find this line near the bottom:

```js
const API = (window.ROCKSTARZ_API || 'http://localhost:4000') + '/api';
```

**Option A — Direct edit (simplest):**
Change it to:
```js
const API = 'https://YOUR-RAILWAY-URL.up.railway.app/api';
```

**Option B — Netlify snippet injection (no code edit needed):**
In Netlify → Site settings → Build & deploy → Post processing → Snippet injection → Add to `<head>`:
```html
<script>window.ROCKSTARZ_API = 'https://YOUR-RAILWAY-URL.up.railway.app';</script>
```

---

## STEP 3 — Deploy the Frontend (Netlify)

1. Go to **https://app.netlify.com** → **"Add new site"** → **"Deploy manually"**
2. Drag & drop the `frontend/` folder into the deploy box
3. ✅ Done! Your site is live.

**Or via GitHub:**
1. Push `frontend/` to a GitHub repo
2. Netlify → "Import from Git" → select repo
3. Build command: *(leave blank)*
4. Publish directory: `.` (root)
5. Deploy

---

## Default Admin Credentials
- **Password:** `rocky@17`
- **Access:** Click the site title **5 times quickly**

Change the password immediately from the Admin Panel after first login.

---

## Features Checklist
- ✅ Full Node.js + SQLite API backend
- ✅ Admin panel (5-click + password)
- ✅ Upload episodes with title, thumbnail, embed codes
- ✅ Dailymotion + Rumble dual embed support
- ✅ Edit / delete any episode
- ✅ Change site title, special tile thumbnail & label
- ✅ Change admin password
- ✅ Special episode folder (expandable to fullscreen)
- ✅ 2-column glassmorphism tile grid (newest first)
- ✅ Anonymous comments per episode
- ✅ Live search with "Coming Soon" fallback
- ✅ Custom glowing cursor with ring follow
- ✅ Color-cycling glow on all headings/titles
- ✅ Animated star particle background
- ✅ Smooth scroll-reveal animations
- ✅ Fully responsive (mobile ready)
- ✅ Password-protected admin panel

---

## Local Development

```bash
# Backend
cd backend
npm install
npm run dev   # runs on http://localhost:4000

# Frontend — just open index.html in a browser
# (API defaults to localhost:4000)
```

---

## Adding Videos (Admin Panel Workflow)

1. Upload your video to **Dailymotion** (primary) and **Rumble** (backup)
2. Get the embed code from each platform
3. Click the site title **5 times** → enter password (`rocky@17`)
4. Fill in: Title, Episode Number, Season, Genre, Thumbnail URL, Embed codes
5. Set **"Special Episode"** to Yes if it belongs in the top folder
6. Click **UPLOAD EPISODE** — it appears instantly on the site

---

## Folder Structure
```
rockstarz/
├── backend/
│   ├── server.js        ← Express API + SQLite
│   ├── package.json
│   ├── Procfile         ← for Railway/Heroku
│   └── .gitignore
└── frontend/
    ├── index.html       ← Entire frontend (self-contained)
    └── netlify.toml     ← Netlify SPA redirect rule
```
