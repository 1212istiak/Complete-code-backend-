# The Voice of Rockstar'z — Setup & Deployment Guide

## Project Structure
```
rockstarz/
├── server.js              ← Main Express server
├── package.json
├── .env.example           ← Copy to .env and fill in your values
├── .gitignore
├── models/
│   ├── Episode.js         ← MongoDB schema for episodes
│   └── Card.js            ← MongoDB schema for browse cards
├── routes/
│   ├── episodes.js        ← CRUD API for episodes
│   ├── cards.js           ← CRUD API + image upload for cards
│   └── admin.js           ← Login + JWT auth
├── middleware/
│   └── auth.js            ← JWT verification middleware
├── public/
│   └── index.html         ← Full frontend (served by Express)
└── uploads/               ← Local image storage (dev only)
```

---

## Local Development (Your Computer)

### Step 1: Install Node.js
Download from https://nodejs.org/ — install the LTS version.

### Step 2: Install MongoDB locally (optional)
OR use MongoDB Atlas (free cloud DB — recommended, see Step 3).

### Step 3: Copy and fill your .env
```bash
cp .env.example .env
```
Edit `.env`:
```
MONGO_URI=mongodb://localhost:27017/rockstarz
JWT_SECRET=any_long_random_string_here_make_it_complex
ADMIN_PASSWORD=your_password_here
PORT=3000
IMAGE_STORAGE=local
```

### Step 4: Install dependencies
```bash
npm install
```

### Step 5: Run
```bash
npm run dev     # development (auto-restarts on changes)
# or
npm start       # production
```

Open: **http://localhost:3000**

---

## FREE Deployment Options

---

### OPTION A: Railway (Recommended — Easiest)
**Free tier:** $5 credit/month — enough for a low-traffic site.

**Steps:**
1. Create account at https://railway.app
2. Install Railway CLI: `npm install -g @railway/cli`
3. In your project folder:
   ```bash
   railway login
   railway init
   railway up
   ```
4. Add environment variables in Railway dashboard → your project → Variables:
   ```
   MONGO_URI=mongodb+srv://...  (from MongoDB Atlas, see below)
   JWT_SECRET=your_secret
   ADMIN_PASSWORD=your_password
   IMAGE_STORAGE=cloudinary
   CLOUDINARY_CLOUD_NAME=...
   CLOUDINARY_API_KEY=...
   CLOUDINARY_API_SECRET=...
   PORT=3000
   ```
5. Railway gives you a free `.up.railway.app` domain automatically.

---

### OPTION B: Render (Also free)
**Free tier:** Spins down after 15 min inactivity (first request is slow), but fully free.

**Steps:**
1. Push your code to GitHub first (see Git section below)
2. Create account at https://render.com
3. New → Web Service → Connect your GitHub repo
4. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Environment:** Node
5. Add the same environment variables as Railway above
6. Render gives you a free `.onrender.com` domain.

---

### OPTION C: Fly.io
**Free tier:** 3 shared VMs free — very reliable.
```bash
npm install -g flyctl
fly auth login
fly launch    # follow prompts
fly deploy
```

---

## MongoDB Atlas (Free Cloud Database)
Your server needs a database. MongoDB Atlas has a **forever-free M0 cluster** (512MB storage).

**Steps:**
1. Go to https://cloud.mongodb.com
2. Sign up → Create a free cluster (M0 — free forever)
3. Database Access → Add a user (username + password)
4. Network Access → Add IP Address → **Allow access from anywhere** (0.0.0.0/0)
5. Clusters → Connect → Connect your application
6. Copy the connection string. It looks like:
   ```
   mongodb+srv://youruser:yourpassword@cluster0.xxxxx.mongodb.net/rockstarz
   ```
7. Paste that as your `MONGO_URI` environment variable.

---

## Cloudinary (Free Image Hosting)
Local file uploads get deleted when your server restarts on Render/Railway.
Use Cloudinary for permanent image storage.

**Steps:**
1. Sign up at https://cloudinary.com (free tier: 25GB storage)
2. Dashboard → copy your **Cloud name**, **API Key**, **API Secret**
3. Add to your environment variables:
   ```
   IMAGE_STORAGE=cloudinary
   CLOUDINARY_CLOUD_NAME=your_cloud_name
   CLOUDINARY_API_KEY=123456789
   CLOUDINARY_API_SECRET=your_secret
   ```

---

## Custom Domain (Free)
Both Railway and Render let you add a custom domain for free.

**Free domain options:**
- **Freenom** — .tk, .ml, .ga, .cf, .gq domains (completely free)
- **js.org** — free if your project is JavaScript/open source
- Buy a .com on Namecheap (~$10/year)

**To connect:**
1. In Railway/Render → Settings → Custom Domains → Add domain
2. Add a CNAME record in your domain's DNS settings pointing to the Railway/Render URL

---

## Git Setup (Required for Render/Railway GitHub deploy)
```bash
git init
git add .
git commit -m "Initial commit"
```
Create a repo on GitHub, then:
```bash
git remote add origin https://github.com/yourusername/rockstarz.git
git push -u origin main
```

---

## Admin Panel Usage
- Open your site → click the **⚙** icon in the top-right nav (or click the logo 5 times)
- Default password: whatever you set in `ADMIN_PASSWORD` in .env
- **Episodes tab:** Add episode → paste Dailymotion iframe → paste Rumble iframe → Save
- **Cards tab:** Add card → upload thumbnail image → paste embed codes → Save
- **Drag to reorder** episodes in the admin list
- JWT token lasts 12 hours, then you need to log in again

---

## API Reference
| Method | Endpoint | Auth | Description |
|--------|----------|------|-------------|
| GET | /api/episodes | No | Get all episodes |
| POST | /api/episodes | Yes | Create episode |
| PUT | /api/episodes/:id | Yes | Update episode |
| DELETE | /api/episodes/:id | Yes | Delete episode |
| POST | /api/episodes/reorder | Yes | Reorder (drag-drop) |
| GET | /api/cards | No | Get all cards |
| POST | /api/cards | Yes | Create card + image upload |
| PUT | /api/cards/:id | Yes | Update card + optional new image |
| DELETE | /api/cards/:id | Yes | Delete card + its image |
| POST | /api/cards/reorder | Yes | Reorder cards |
| POST | /api/admin/login | No | Get JWT token |
| POST | /api/admin/change-password | Yes | Change password |
| GET | /api/admin/verify | Yes | Verify token |

---

## Recommended: Full Free Stack
| Service | What it does | Cost |
|---------|-------------|------|
| Railway | Hosts your Node.js server | Free ($5 credit/mo) |
| MongoDB Atlas | Hosts your database | Free forever (M0) |
| Cloudinary | Hosts uploaded images | Free (25GB) |
| Freenom/Namecheap | Custom domain | Free / ~$10/yr |

**Total cost: $0/month** for a low-traffic site.
